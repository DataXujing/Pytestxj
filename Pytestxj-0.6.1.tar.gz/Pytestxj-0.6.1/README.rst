Pytestxj
========

It is a test module which build by DataXujing, it test the python module that can install by pip and 
use in py2.7 and py3.5.

Introduction
------------

::

    import pytestxu as pu
    pu.testpy(1,2)
    pu.testpy('Python','is an intersting tool!')

    


Supports
--------
Tested on Python 2.7, 3.5, 3.6

* pip install Pytestxj
* Download: https://pypi.python.org/pypi/Pytestxj
* Documentation: https://pypi.python.org/pypi/Pytestxj

